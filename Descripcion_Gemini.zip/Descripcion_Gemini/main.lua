require "import"
import "android.content.Context"
import "java.io.File"

-- 1. DEFINE TU VERSIÓN ACTUAL AQUÍ
local PLUGIN_VERSION = 1.0 

local context = activity or service

-- Detección de ruta (Lógica que ya tenías)
local function exists(path) return File(path).exists() end
local basePath = nil
local possiblePaths = {
    "/storage/emulated/0/解说/Plugins/Descripcion_Gemini",
    "/storage/emulated/0/解说/Complementos/Descripcion_Gemini"
}
for _, path in ipairs(possiblePaths) do
    if exists(path) then basePath = path break end
end
if not basePath then basePath = possiblePaths[1]; File(basePath).mkdirs() end

package.path = basePath .. "/?.lua;" .. package.path
local config = require("config")
local utils = require("utils")
local gemini = require("gemini_vision")
local ui = require("ui")
local history = require("history")
local updater = require("updater") -- Importar el actualizador

-- Inicialización
config.init(basePath)
utils.init(context)
history.init()
ui.init(context, config, utils, gemini, history)
updater.init(service, context, basePath) -- Inicializar actualizador

-- 2. COMPROBACIÓN AUTOMÁTICA
-- Se ejecuta en segundo plano, no bloquea el inicio del plugin
updater.check(PLUGIN_VERSION)

-- Lógica principal
local cfgData = config.loadConfig()
local currentNode = node 

if cfgData.api_key == "" then
    service.asyncSpeak("Bienvenido. Configura tu API Key.")
    ui.showConfig()
else
    ui.showMenu(currentNode)
end

return true