-- main
require "import"
import "android.content.Context"
import "java.io.File"

local context = activity or service

-- Función auxiliar para verificar existencia
local function exists(path)
    return File(path).exists()
end

-- 1. DETECCIÓN DE RUTA (Plugins vs Complementos)
local basePath = nil
local possiblePaths = {
    "/storage/emulated/0/解说/Plugins/Descripcion_Gemini",
    "/storage/emulated/0/解说/Complementos/Descripcion_Gemini"
}

for _, path in ipairs(possiblePaths) do
    if exists(path) then
        basePath = path
        break
    end
end

-- Si no se encuentra en ninguna, usamos la primera por defecto (o mostramos error)
if not basePath then
    basePath = possiblePaths[1]
    -- Intentamos crearla para que no falle el require
    File(basePath).mkdirs()
end

-- 2. CARGA DE MÓDULOS
package.path = basePath .. "/?.lua;" .. package.path
local config = require("config")
local utils = require("utils")
local gemini = require("gemini_vision")
local ui = require("ui")
local history = require("history")

-- 3. INICIALIZACIÓN
config.init(basePath)
utils.init(context)
history.init()
ui.init(context, config, utils, gemini, history)

local cfgData = config.loadConfig()

-- CAPTURA DEL NODO GLOBAL (Para cuando se ejecuta desde el menú de Jieshuo)
local currentNode = node 

-- 4. LÓGICA DE ARRANQUE
if cfgData.api_key == "" then
    service.asyncSpeak("Bienvenido. Configura tu API Key.")
    ui.showConfig()
else
    -- Pasamos el nodo al menú para que pueda ser usado en "Elemento Enfocado"
    ui.showMenu(currentNode)
end

return true