require "import"
import "java.io.File"
import "java.util.Arrays"
import "java.util.ArrayList"
import "java.util.Collections"

local M = {}
local json = require("cjson")

-- Ruta base para el historial (Dentro de Documents)
local historyPath = "/storage/emulated/0/Documents/Descripcion_Gemini/Historial"

function M.init()
    local f = File(historyPath)
    if not f.exists() then
        f.mkdirs()
    end
end

-- Generar un ID único basado en la fecha
local function generateID()
    return os.time()
end

-- Guardar o Actualizar una sesión
function M.saveSession(sessionData)
    if not sessionData.id then
        sessionData.id = generateID()
        sessionData.date = os.date("%Y-%m-%d %H:%M:%S")
    end
    
    local filename = historyPath .. "/chat_" .. sessionData.id .. ".json"
    local f = io.open(filename, "w")
    if f then
        f:write(json.encode(sessionData))
        f:close()
        return true
    end
    return false
end

-- Leer una sesión específica
function M.loadSession(filename)
    local path = historyPath .. "/" .. filename
    local f = io.open(path, "r")
    if f then
        local content = f:read("*a")
        f:close()
        local status, res = pcall(json.decode, content)
        if status then return res end
    end
    return nil
end

-- Eliminar una sesión
function M.deleteSession(filename)
    local f = File(historyPath, filename)
    return f.delete()
end

-- Obtener lista de historiales (ordenados del más reciente al más antiguo)
function M.getHistoryList()
    local dir = File(historyPath)
    local filesJavaArray = dir.listFiles() -- Esto devuelve un Array de Java
    local sessions = {}
    
    if filesJavaArray then
        -- CORRECCIÓN: Convertir Array de Java a Tabla de Lua para poder ordenar
        local filesLuaTable = {}
        for i = 0, #filesJavaArray - 1 do
            table.insert(filesLuaTable, filesJavaArray[i])
        end
        
        -- Ahora sí podemos usar table.sort sin errores
        table.sort(filesLuaTable, function(a, b) 
            return a.lastModified() > b.lastModified() 
        end)
        
        -- Iterar sobre la tabla ordenada
        for _, file in ipairs(filesLuaTable) do
            if file.getName():match("%.json$") then
                local s = M.loadSession(file.getName())
                if s then
                    -- Resumen seguro
                    local resumen = s.description or "Sin descripción"
                    if #resumen > 50 then resumen = string.sub(resumen, 1, 50) .. "..." end
                    
                    table.insert(sessions, {
                        filename = file.getName(),
                        date = s.date,
                        summary = resumen,
                        fullData = s
                    })
                end
            end
        end
    end
    return sessions
end

return M
