-- history.lua optimizado con renombrado y borrado masivo
require "import"
import "java.io.File"
import "java.util.Arrays"
import "java.util.ArrayList"

local M = {}
local json = require("cjson")
local historyPath = "/storage/emulated/0/Documents/Descripcion_Gemini/Historial"

function M.init()
    local f = File(historyPath)
    if not f.exists() then
        f.mkdirs()
    end
end

local function generateID()
    return os.time()
end

function M.saveSession(sessionData)
    if not sessionData.id then
        sessionData.id = generateID()
        sessionData.date = os.date("%Y-%m-%d %H:%M:%S")
    end
    local filename = historyPath .. "/chat_" .. sessionData.id .. ".json"
    local f = io.open(filename, "w")
    if f then
        f:write(json.encode(sessionData))
        f:close()
        return true
    end
    return false
end

function M.loadSession(filename)
    local path = historyPath .. "/" .. filename
    local f = io.open(path, "r")
    if f then
        local content = f:read("*a")
        f:close()
        local status, res = pcall(json.decode, content)
        if status then return res end
    end
    return nil
end

function M.deleteSession(filename)
    local f = File(historyPath, filename)
    if f.exists() then
        return f.delete()
    end
    return false
end

-- Renombrar una conversación (actualiza el campo title en el JSON)
function M.renameSession(filename, newTitle)
    local session = M.loadSession(filename)
    if not session then return false end
    session.title = newTitle
    local path = historyPath .. "/" .. filename
    local f = io.open(path, "w")
    if f then
        f:write(json.encode(session))
        f:close()
        return true
    end
    return false
end

-- Vaciar todo el historial de conversaciones de forma segura
function M.clearAllHistory()
    local dir = File(historyPath)
    local files = dir.listFiles()
    local deletedCount = 0
    if files then
        for i = 0, #files - 1 do
            local file = files[i]
            if file.isFile() and file.getName():match("%.json$") then
                if file.delete() then
                    deletedCount = deletedCount + 1
                end
            end
        end
    end
    return deletedCount
end

function M.getHistoryList()
    local dir = File(historyPath)
    local filesJavaArray = dir.listFiles()
    local sessions = {}
    
    if filesJavaArray then
        local filesLuaTable = {}
        for i = 0, #filesJavaArray - 1 do
            table.insert(filesLuaTable, filesJavaArray[i])
        end
        
        table.sort(filesLuaTable, function(a, b)
            return a.lastModified() > b.lastModified()
        end)
        
        for _, file in ipairs(filesLuaTable) do
            local fName = file.getName()
            if fName:match("%.json$") then
                local s = M.loadSession(fName)
                if s then
                    local label = s.title or s.description or "Sin descripción"
                    if #label > 60 then
                        label = string.sub(label, 1, 60) .. "..."
                    end
                    table.insert(sessions, {
                        filename = fName,
                        date = s.date or "Sin fecha",
                        summary = label,
                        fullData = s
                    })
                end
            end
        end
    end
    return sessions
end

return M