require "import"
import "android.speech.*"
import "android.content.Intent"
import "android.widget.*"
import "android.view.*"
import "com.androlua.LuaDialog"
import "java.util.ArrayList"
import "android.widget.ArrayAdapter"
import "android.widget.AdapterView"
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local LayoutParams = luajava.bindClass("android.widget.LinearLayout$LayoutParams")

local M = {}
local context, config, utils, gemini_api, history_manager

function M.init(ctx, cfg, utl, gem, hist)
    context = ctx
    config = cfg
    utils = utl
    gemini_api = gem
    history_manager = hist
end

-- ==================================================
-- 1. CONFIGURACIÓN (Sin textStyle="bold" para evitar errores)
-- ==================================================
function M.showConfig()
    local data = config.loadConfig()
    
    local layout = {
        ScrollView,
        layout_width="fill",
        layout_height="fill",
        {
            LinearLayout,
            orientation="vertical",
            padding="16dp",
            layout_width="fill",
            
            -- API Y MODELO
            {TextView, text="API Key", textSize="16sp"}, -- Quitamos textStyle
            {EditText, id="edtKey", text=data.api_key, hint="Pegar API Key"},
            
            {TextView, text="Modelo IA", textSize="16sp", paddingTop="10dp"}, -- Quitamos textStyle
            {EditText, id="edtModel", text=data.model},
            
            -- OPCIONES DE COMPORTAMIENTO
            {TextView, text="Comportamiento", textSize="16sp", paddingTop="15dp"}, -- Quitamos textStyle
            {CheckBox, id="cbShowUI", text="Mostrar chat al finalizar", checked=data.show_ui_on_finish},
            
            -- FILTRO DE SEGURIDAD
            {CheckBox, id="cbSafety", text="Activar Filtro de Seguridad (Modo Niños)", checked=data.safety_filter},
            {TextView, text="Desactivado: Análisis forense sin censura.\nActivado: Bloquea contenido explícito.", textSize="12sp", textColor="0xFFAAAAAA", paddingBottom="10dp"},

            -- PROMPTS PERSONALIZABLES
            {TextView, text="Prompt: Pantalla Completa", textSize="16sp", paddingTop="10dp"}, -- Quitamos textStyle
            {EditText, id="edtSysPrompt", text=data.system_prompt, hint="Instrucciones imagen general...", minLines=3},
            
            {TextView, text="Prompt: Elemento/Botón", textSize="16sp", paddingTop="10dp"}, -- Quitamos textStyle
            {EditText, id="edtElemPrompt", text=data.element_prompt, hint="Instrucciones para iconos...", minLines=2},
            
            {TextView, text="Prompt: Video", textSize="16sp", paddingTop="10dp"}, -- Quitamos textStyle
            {EditText, id="edtVidPrompt", text=data.video_prompt, hint="Instrucciones para video...", minLines=3, paddingBottom="20dp"},
        }
    }

    local dlg = LuaDialog(context)
    dlg.setTitle("Configuración Avanzada")
    dlg.setView(loadlayout(layout))
    dlg.setPositiveButton("Guardar", function()
        data.api_key = edtKey.getText().toString()
        data.model = edtModel.getText().toString()
        data.show_ui_on_finish = cbShowUI.isChecked()
        
        -- Guardar nuevas opciones
        data.safety_filter = cbSafety.isChecked()
        data.system_prompt = edtSysPrompt.getText().toString()
        data.element_prompt = edtElemPrompt.getText().toString()
        data.video_prompt = edtVidPrompt.getText().toString()
        
        config.saveConfig(data)
        utils.vibrate(50)
        service.asyncSpeak("Configuración actualizada")
    end)
    dlg.setNegativeButton("Cancelar", nil)
    dlg.show()
end

-- ==================================================
-- 2. GENERADOR DE SCRIPTS (Sin cambios)
-- ==================================================
function M.showGestureGenerator()
    local scriptTemplate = [[
-- Script Generado para Gemini Vision
require "import"
import "java.io.File"

local basePath = nil
local paths = {
    "/storage/emulated/0/解说/Plugins/Descripcion_Gemini",
    "/storage/emulated/0/解说/Complementos/Descripcion_Gemini"
}

for _, p in ipairs(paths) do
    if File(p).exists() then basePath = p break end
end

if not basePath then
    service.asyncSpeak("Error: No se encuentra el plugin")
    return
end

package.path = basePath .. "/?.lua;" .. package.path
local config = require("config")
local utils = require("utils")
local gemini = require("gemini_vision")
local history = require("history")
local ui = require("ui")

local context = activity or service
config.init(basePath)
utils.init(context)
history.init()
ui.init(context, config, utils, gemini, history)

ui.ejecutarAccionDirecta("%s", %s)
return true
]]
    local actions = {"Copiar Script: Describir Foco", "Copiar Script: Pantalla Completa"}
    local layout = { LinearLayout, orientation="vertical", { ListView, id="lvGen", layout_width="fill", layout_height="wrap" } }
    local dlg = LuaDialog(context)
    dlg.setTitle("Generar Scripts")
    dlg.setView(loadlayout(layout))
    
    local jList = ArrayList() for _,v in ipairs(actions) do jList.add(v) end
    local adp = ArrayAdapter(context, android.R.layout.simple_list_item_1, jList)
    lvGen.setAdapter(adp)
    
    lvGen.setOnItemClickListener(AdapterView.OnItemClickListener({
        onItemClick = function(parent, view, pos, id)
            local code = (pos == 0) and string.format(scriptTemplate, "elemento", "node") or string.format(scriptTemplate, "pantalla", "nil")
            service.copy(code)
            service.asyncSpeak("Código copiado")
            dlg.dismiss()
        end
    }))
    dlg.show()
end

-- ==================================================
-- 3. HISTORIAL (Sin cambios)
-- ==================================================
function M.showHistoryList()
    local sessions = history_manager.getHistoryList()
    
    local layout = {
        LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill",
        {
            LinearLayout, orientation = "horizontal", layout_width = "fill", padding = "8dp",
            { TextView, id = "tvHeader", text = "Historial (" .. #sessions .. ")", textSize = "16sp", layout_weight = 1 },
            { Button, id = "btnClearAll", text = "Vaciar Todo", layout_width = "wrap" }
        },
        {
            ListView, id = "lvH", layout_width = "fill", layout_height = "fill"
        }
    }
    
    local d = LuaDialog(context)
    d.setTitle("Historial de Consultas")
    d.setView(loadlayout(layout))
    
    if #sessions == 0 then
        tvHeader.setText("Historial (0)")
        btnClearAll.setEnabled(false)
    end
    
    local lN = ArrayList()
    for _, s in ipairs(sessions) do
        lN.add(s.date .. "\n" .. s.summary)
    end
    
    local adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, lN)
    lvH.setAdapter(adapter)
    
    -- Clic simple: Abrir conversación
    lvH.setOnItemClickListener(AdapterView.OnItemClickListener({
        onItemClick = function(p, v, pos, id)
            d.dismiss()
            M.showChat(nil, nil, sessions[pos + 1].fullData)
        end
    }))
    
    -- Clic largo: Menú de opciones por conversación (Renombrar, Eliminar, Abrir)
    lvH.setOnItemLongClickListener(AdapterView.OnItemLongClickListener({
        onItemLongClick = function(p, v, pos, id)
            local itemSession = sessions[pos + 1]
            local menuItems = ArrayList()
            menuItems.add("Abrir chat")
            menuItems.add("Renombrar chat")
            menuItems.add("Eliminar este chat")
            
            local optDlg = LuaDialog(context)
            optDlg.setTitle("Opciones: " .. itemSession.summary)
            local optList = ListView(context)
            optList.setAdapter(ArrayAdapter(context, android.R.layout.simple_list_item_1, menuItems))
            
            optList.setOnItemClickListener(AdapterView.OnItemClickListener({
                onItemClick = function(op, ov, oPos, oId)
                    optDlg.dismiss()
                    if oPos == 0 then
                        d.dismiss()
                        M.showChat(nil, nil, itemSession.fullData)
                    elseif oPos == 1 then
                        -- Diálogo para Renombrar
                        local renLayout = {
                            LinearLayout, orientation = "vertical", padding = "16dp",
                            { TextView, text = "Nuevo nombre para la conversación:" },
                            { EditText, id = "edtNewTitle", text = itemSession.fullData.title or itemSession.summary, layout_width = "fill" }
                        }
                        local renDlg = LuaDialog(context)
                        renDlg.setTitle("Renombrar Chat")
                        renDlg.setView(loadlayout(renLayout))
                        renDlg.setPositiveButton("Guardar", function()
                            local newName = edtNewTitle.getText().toString()
                            if newName and newName ~= "" then
                                history_manager.renameSession(itemSession.filename, newName)
                                service.asyncSpeak("Nombre actualizado")
                                d.dismiss()
                                M.showHistoryList()
                            end
                        end)
                        renDlg.setNegativeButton("Cancelar", nil)
                        renDlg.show()
                    elseif oPos == 2 then
                        -- Eliminar individual
                        history_manager.deleteSession(itemSession.filename)
                        service.asyncSpeak("Chat eliminado")
                        d.dismiss()
                        M.showHistoryList()
                    end
                end
            }))
            
            optDlg.setView(optList)
            optDlg.setNegativeButton("Cancelar", nil)
            optDlg.show()
            return true
        end
    }))
    
    -- Botón de Vaciar Todo con diálogo de confirmación estricto
    btnClearAll.setOnClickListener(function()
        local confirmDlg = LuaDialog(context)
        confirmDlg.setTitle("¿Vaciar todo el historial?")
        confirmDlg.setMessage("Se eliminarán las " .. #sessions .. " conversaciones guardadas. Esta acción no se puede deshacer.")
        confirmDlg.setPositiveButton("Eliminar todo", function()
            local total = history_manager.clearAllHistory()
            service.asyncSpeak("Se eliminaron " .. total .. " conversaciones")
            utils.vibrate(80)
            d.dismiss()
        end)
        confirmDlg.setNegativeButton("Cancelar", nil)
        confirmDlg.show()
    end)
    
    d.setPositiveButton("Cerrar", nil)
    d.show()
end

-- ==================================================
-- 4. CHAT (Sin cambios)
-- ==================================================
function M.showChat(imageBase64, initialDesc, savedSession)
    local data = config.loadConfig()
    local currentSession = savedSession or {
        id = nil, date = nil, image_data = imageBase64, description = initialDesc, history = {}
    }
    
    local apiHistory = {
        { role = "user", parts = {} },
        { role = "model", parts = {{text = currentSession.description}} }
    }
    
    local visualInput = currentSession.image_data
    if type(visualInput) == "string" then
        table.insert(apiHistory[1].parts, { inline_data = { mime_type = "image/jpeg", data = visualInput } })
    elseif type(visualInput) == "table" then
        for i, img in ipairs(visualInput) do
            table.insert(apiHistory[1].parts, { text = "Cuadro " .. i })
            table.insert(apiHistory[1].parts, { inline_data = { mime_type = "image/jpeg", data = img } })
        end
    end
    
    table.insert(apiHistory[1].parts, { text = data.system_prompt })
    
    if savedSession and savedSession.history then
        for _, msg in ipairs(savedSession.history) do
            local r = (msg.role == "Tú") and "user" or "model"
            table.insert(apiHistory, { role = r, parts = {{text = msg.text}} })
        end
    end
    
    local chatDialog = LuaDialog(context)
    chatDialog.setTitle("Chat Gemini")
    
    -- Interfaz modificada para incluir el botón "Dictar"
    local mainLayout = {
        LinearLayout, orientation="vertical", layout_width="fill", layout_height="fill",
        {
            ScrollView, layout_weight=1, layout_width="fill",
            {
                LinearLayout, id="chatContainer", orientation="vertical", layout_width="fill", padding="10dp"
            }
        },
        {
            LinearLayout, orientation="horizontal", layout_width="fill", padding="5dp",
            { EditText, id="edtQuery", hint="Escribe o dicta...", layout_weight=1 },
            { Button, text="Dictar", id="btnDictar" },
            { Button, text="Enviar", id="btnSend" }
        }
    }
    chatDialog.setView(loadlayout(mainLayout))
    
    local function addMessageBlock(role, text)
        local bg = (role == "Tú") and "0xFF303030" or "0xFF202020"
        local item = {
            LinearLayout, orientation="vertical", backgroundColor=bg, padding="8dp",
            { TextView, text=role..": "..text, textSize="16sp", textColor="0xFFFFFFFF", textIsSelectable=true, focusable=true },
            { Button, text="Copiar", layout_width="wrap", layout_gravity="right", onClick=function()
                service.copy(text)
                service.asyncSpeak("Copiado")
                utils.vibrate(30)
            end }
        }
        local v = loadlayout(item)
        local p = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 25, 0, 0)
        chatContainer.addView(v, p)
        chatContainer.post(function()
            local s = chatContainer.getParent()
            if s then s.fullScroll(ScrollView.FOCUS_DOWN) end
        end)
    end
    
    if currentSession.description then addMessageBlock("IA", currentSession.description) end
    
    if currentSession.history then
        for _,m in ipairs(currentSession.history) do addMessageBlock(m.role, m.text) end
    end
    
    if not currentSession.id then history_manager.saveSession(currentSession) end
    
    -- Lógica del botón Enviar
    btnSend.setOnClickListener(function()
        local q = edtQuery.getText().toString()
        if q == "" then return end
        addMessageBlock("Tú", q)
        edtQuery.setText("")
        utils.vibrate(30)
        service.asyncSpeak("Pensando...")
        
        gemini_api.sendToGemini(data.api_key, data.model, apiHistory, nil, q, function(s, r)
            if s then
                service.asyncSpeak("Respuesta recibida")
                utils.vibrate(50)
                addMessageBlock("IA", r)
                table.insert(apiHistory, { role="user", parts={{text=q}} })
                table.insert(apiHistory, { role="model", parts={{text=r}} })
                if not currentSession.history then currentSession.history={} end
                table.insert(currentSession.history, { role="Tú", text=q })
                table.insert(currentSession.history, { role="IA", text=r })
                history_manager.saveSession(currentSession)
            else
                service.asyncSpeak("Error: "..r)
            end
        end, data.safety_filter)
    end)
    
    -- Lógica del botón Dictar usando la API nativa de Android
    btnDictar.setOnClickListener(function()
        local SpeechRecognizer = luajava.bindClass("android.speech.SpeechRecognizer")
        local RecognizerIntent = luajava.bindClass("android.speech.RecognizerIntent")
        local Locale = luajava.bindClass("java.util.Locale")
        
        local speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        local intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        
        local listener = luajava.createProxy("android.speech.RecognitionListener", {
            onReadyForSpeech = function(params) service.asyncSpeak("Escuchando") utils.vibrate(30) end,
            onResults = function(results)
                local data = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if data and data.size() > 0 then
                    local textoDictado = data.get(0)
                    local textoActual = edtQuery.getText().toString()
                    if textoActual ~= "" then
                        edtQuery.setText(textoActual .. " " .. textoDictado)
                    else
                        edtQuery.setText(textoDictado)
                    end
                    edtQuery.setSelection(edtQuery.getText().length())
                end
                speechRecognizer.destroy()
            end,
            onError = function(error)
                service.asyncSpeak("Error de dictado")
                speechRecognizer.destroy()
            end,
            onBeginningOfSpeech = function() end,
            onBufferReceived = function(buffer) end,
            onEndOfSpeech = function() end,
            onEvent = function(eventType, params) end,
            onPartialResults = function(partialResults) end,
            onRmsChanged = function(rmsdB) end
        })
        
        speechRecognizer.setRecognitionListener(listener)
        speechRecognizer.startListening(intent)
    end)
    
    chatDialog.setPositiveButton("Cerrar", nil)
    chatDialog.show()
end


-- ==================================================
-- 5. ACCIÓN DIRECTA (Sin cambios)
-- ==================================================
function M.ejecutarAccionDirecta(tipo, nodo)
    local data = config.loadConfig()
    if data.api_key == "" then service.asyncSpeak("Configura API Key") return end
    if tipo == "video" then M.showVideoSelector(); return end

    utils.vibrate(50)
    service.asyncSpeak((tipo == "elemento") and "Analizando..." or "Analizando pantalla...")
    local mode = (tipo == "elemento") and "element" or "full"

    utils.captureScreen(mode, function(base64)
        local promptUso = data.system_prompt
        if tipo == "elemento" then
            promptUso = data.element_prompt 
        end

        gemini_api.sendToGemini(data.api_key, data.model, {}, base64, promptUso, function(success, resp)
            if success then
                service.asyncSpeak(resp)
                if data.show_ui_on_finish then
                    utils.vibrate(100)
                    M.showChat(base64, resp, nil)
                else
                    local s = { id=nil, date=nil, image_data=base64, description=resp, history={} }
                    history_manager.saveSession(s)
                end
            else
                service.asyncSpeak("Error: " .. resp)
            end
        end, data.safety_filter) 
    end, nodo)
end

-- ==================================================
-- 6. SELECTOR VIDEO (Sin cambios)
-- ==================================================
function M.showVideoSelector()
    local video_manager = require("video_manager")
    video_manager.init(context)
    video_manager.listarVideosRecientes(function(videos)
        if #videos == 0 then service.asyncSpeak("No hay videos") return end
        local vN = ArrayList() for _,v in ipairs(videos) do vN.add(v.name) end
        local l = { LinearLayout, orientation="vertical", { ListView, id="lvV", layout_width="fill", layout_height="wrap" } }
        local d = LuaDialog(context)
        d.setTitle("Video")
        d.setView(loadlayout(l))
        local a = ArrayAdapter(context, android.R.layout.simple_list_item_1, vN)
        lvV.setAdapter(a)
        lvV.setOnItemClickListener(AdapterView.OnItemClickListener({
            onItemClick = function(p,v,pos,id)
                d.dismiss()
                local path = videos[pos+1].path
                local data = config.loadConfig()
                task(200, function()
                    service.asyncSpeak("Procesando...")
                    utils.vibrate(50)
                    local frames = video_manager.capturarSecuenciaVideo(path)
                    if frames then
                        local promptVid = data.video_prompt 
                        gemini_api.sendToGemini(data.api_key, data.model, {}, frames, promptVid, function(s, r)
                            if s then
                                service.asyncSpeak(r)
                                if data.show_ui_on_finish then
                                    M.showChat(frames, r, nil)
                                else
                                    local sess = { id=nil, date=nil, image_data=frames, description=r, history={} }
                                    history_manager.saveSession(sess)
                                end
                            else
                                service.asyncSpeak("Error: "..r)
                            end
                        end, data.safety_filter)
                    else
                        service.asyncSpeak("Error leyendo video")
                    end
                end)
            end
        }))
        d.show()
    end)
end

-- ==================================================
-- 7. MENÚ PRINCIPAL (Sin cambios)
-- ==================================================
function M.showMenu(nodoActual)
    local actions = {"Describir Elemento Enfocado", "Describir Pantalla Completa", "Analizar Video", "Historial", "Crear Gestos", "Configuración"}
    local l = { LinearLayout, orientation="vertical", { ListView, id="lvM", layout_width="fill", layout_height="wrap" } }
    local d = LuaDialog(context)
    d.setTitle("Gemini Vision")
    d.setView(loadlayout(l))
    local jL = ArrayList() for _,v in ipairs(actions) do jL.add(v) end
    local adp = ArrayAdapter(context, android.R.layout.simple_list_item_1, jL)
    lvM.setAdapter(adp)
    lvM.setOnItemClickListener(AdapterView.OnItemClickListener({
        onItemClick = function(p,v,pos,id)
            if pos==5 then M.showConfig(); d.dismiss(); return end
            if pos==4 then M.showGestureGenerator(); d.dismiss(); return end
            if pos==3 then M.showHistoryList(); d.dismiss(); return end
            local data = config.loadConfig()
            if data.api_key=="" then service.asyncSpeak("Configura API"); M.showConfig(); d.dismiss(); return end
            if pos==2 then M.showVideoSelector(); d.dismiss(); return end
            d.dismiss()
            task(500, function()
                local t = (pos==0) and "elemento" or "pantalla"
                M.ejecutarAccionDirecta(t, nodoActual)
            end)
        end
    }))
    d.show()
end

return M