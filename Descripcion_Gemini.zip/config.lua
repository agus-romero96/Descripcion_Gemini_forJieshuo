-- config
require "import"
import "java.io.File"

local M = {}
local json = require("cjson")

local docsPath = "/storage/emulated/0/Documents/Descripcion_Gemini"
local configFile = docsPath .. "/config.json"

function M.init(pluginPath)
    local f = File(docsPath)
    if not f.exists() then f.mkdirs() end

    local file = io.open(configFile, "r")
    if not file then
        M.saveConfig({
            api_key = "",
            model = "gemini-1.5-flash",
            show_ui_on_finish = true,
            -- Filtro de seguridad (true = Protegido/Niños, false = Sin censura/Forense)
            safety_filter = false, 
            
            -- PROMPTS PERSONALIZABLES
            system_prompt = "Actúa como un Especialista en Reconstrucción Visual. Describe la imagen con detalle objetivo y realista. [ALERTA] si hay contenido sensible.",
            
            element_prompt = "Eres un asistente de accesibilidad. Identifica este icono o botón de Android recortado. Sé breve y directo (ej: 'Botón Enviar', 'Foto de perfil'). No describas colores innecesarios.",
            
            video_prompt = "Analiza esta secuencia de fotogramas de un video. Narra la historia cronológica de lo que sucede. Describe el ambiente, las acciones y las emociones. Si detectas peligro, avisa con [ALERTA]."
        })
    else
        file:close()
    end
end

function M.loadConfig()
    local f = io.open(configFile, "r")
    if f then
        local content = f:read("*a")
        f:close()
        local status, res = pcall(json.decode, content)
        if status then 
            -- Migración de datos (si el usuario ya tenía config, añadir lo nuevo)
            if res.show_ui_on_finish == nil then res.show_ui_on_finish = true end
            if res.element_prompt == nil then res.element_prompt = "Identifica este botón o icono brevemente." end
            if res.video_prompt == nil then res.video_prompt = "Narra la historia cronológica de este video." end
            if res.safety_filter == nil then res.safety_filter = false end
            return res 
        end
    end
    return {}
end

function M.saveConfig(data)
    local f = io.open(configFile, "w")
    if f then
        f:write(json.encode(data))
        f:close()
        return true
    end
    return false
end

return M