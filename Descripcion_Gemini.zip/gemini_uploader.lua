-- gemini_uploader.lua
require "import"
import "java.io.File"
import "java.io.FileInputStream"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.net.HttpURLConnection"
import "java.net.URL"
import "android.os.AsyncTask"
local json = require("cjson")

local M = {}

local function readStream(stream)
    if not stream then return "" end
    local reader = BufferedReader(InputStreamReader(stream))
    local sb = {}
    local line = reader.readLine()
    while line do
        table.insert(sb, line)
        line = reader.readLine()
    end
    reader.close()
    return table.concat(sb, "\n")
end

function M.uploadAndWait(apiKey, filePath, mimeType, callback)
    AsyncTask.execute(function()
        local success, err = pcall(function()
            local file = File(filePath)
            if not file.exists() then
                callback(false, "El archivo de video no existe.")
                return
            end
            
            local fileLength = file.length()
            local uploadUrl = URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=" .. apiKey)
            local conn = uploadUrl.openConnection()
            conn.setDoOutput(true)
            conn.setRequestMethod("POST")
            conn.setRequestProperty("X-Goog-Upload-Command", "start, upload, finalize")
            conn.setRequestProperty("X-Goog-Upload-Header-Content-Length", tostring(fileLength))
            conn.setRequestProperty("X-Goog-Upload-Header-Content-Type", mimeType)
            conn.setRequestProperty("Content-Type", mimeType)
            conn.setFixedLengthStreamingMode(fileLength)
            
            -- Streaming en bloques seguros para AndroLua
            local Array = luajava.bindClass("java.lang.reflect.Array")
            local Byte = luajava.bindClass("java.lang.Byte")
            local buffer = Array.newInstance(Byte.TYPE, 8192)
            
            local outputStream = conn.getOutputStream()
            local inputStream = FileInputStream(file)
            local bytesRead = inputStream.read(buffer)
            
            while bytesRead > 0 do
                outputStream.write(buffer, 0, bytesRead)
                bytesRead = inputStream.read(buffer)
            end
            outputStream.flush()
            outputStream.close()
            inputStream.close()
            
            if conn.getResponseCode() == 200 then
                local resText = readStream(conn.getInputStream())
                local fileInfo = json.decode(resText).file
                local fileUri = fileInfo.uri
                local fileName = fileInfo.name -- Suele ser "files/codigo..."
                conn.disconnect()
                
                -- Fase 2: Polling (Esperar a que Google procese el video)
                local isProcessing = true
                local attempts = 0
                while isProcessing and attempts < 30 do -- Máximo 1 minuto y medio
                    attempts = attempts + 1
                    local checkUrl = URL("https://generativelanguage.googleapis.com/v1beta/" .. fileName .. "?key=" .. apiKey)
                    local checkConn = checkUrl.openConnection()
                    checkConn.setRequestMethod("GET")
                    
                    if checkConn.getResponseCode() == 200 then
                        local stateInfo = json.decode(readStream(checkConn.getInputStream()))
                        local state = stateInfo.state
                        if state == "ACTIVE" then
                            isProcessing = false
                            checkConn.disconnect()
                            callback(true, fileUri)
                            return
                        elseif state == "FAILED" then
                            isProcessing = false
                            checkConn.disconnect()
                            callback(false, "Google no pudo procesar el video.")
                            return
                        end
                    end
                    checkConn.disconnect()
                    luajava.bindClass("java.lang.Thread").sleep(3000) -- Esperar 3 segundos
                end
                
                if isProcessing then callback(false, "Tiempo de espera agotado.") end
            else
                local errText = readStream(conn.getErrorStream())
                conn.disconnect()
                callback(false, "Fallo HTTP " .. conn.getResponseCode() .. ": " .. errText)
            end
        end)
        
        if not success then callback(false, "Excepción crítica: " .. tostring(err)) end
    end)
end

return M