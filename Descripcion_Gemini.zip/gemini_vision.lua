-- Gemini_vision
require "import"
import "com.androlua.Http"
local json = require("cjson")

local M = {}

-- Construye el cuerpo del mensaje
-- useFilter: Booleano (viene de config.safety_filter)
local function buildBody(historial, visualInput, userPrompt, useFilter)
    local contents = {}
    
    for _, msg in ipairs(historial) do
        table.insert(contents, msg)
    end

    local currentParts = {}
    
    if #historial == 0 and visualInput then
        if type(visualInput) == "string" then
            table.insert(currentParts, {
                inline_data = { mime_type = "image/jpeg", data = visualInput }
            })
        elseif type(visualInput) == "table" then
            for i, imgData in ipairs(visualInput) do
                table.insert(currentParts, { text = "Cuadro " .. i .. " del video:" })
                table.insert(currentParts, {
                    inline_data = { mime_type = "image/jpeg", data = imgData }
                })
            end
        end
    end
    
    table.insert(currentParts, { text = userPrompt })

    table.insert(contents, {
        role = "user",
        parts = currentParts
    })

    -- LÓGICA DE FILTRO DINÁMICO
    local threshold = "BLOCK_NONE" -- Por defecto: SIN CENSURA (Modo Forense)
    
    if useFilter then
        threshold = "BLOCK_ONLY_HIGH" -- Modo Niños: Bloquea lo peligroso
    end

    local safetySettings = {
        { category = "HARM_CATEGORY_HARASSMENT", threshold = threshold },
        { category = "HARM_CATEGORY_HATE_SPEECH", threshold = threshold },
        { category = "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold = threshold },
        { category = "HARM_CATEGORY_DANGEROUS_CONTENT", threshold = threshold }
    }

    return { contents = contents, safetySettings = safetySettings }
end

-- Nueva firma con 'useFilter' al final
function M.sendToGemini(apiKey, model, historial, visualInput, prompt, callback, useFilter)
    local url = "https://generativelanguage.googleapis.com/v1beta/models/" .. model .. ":generateContent?key=" .. apiKey
    local headers = { ["Content-Type"] = "application/json" }
    
    local bodyTable = buildBody(historial, visualInput, prompt, useFilter)
    local bodyJson = json.encode(bodyTable)

    Http.post(url, bodyJson, headers, function(code, responseBody)
        if code == 200 then
            local decoded = json.decode(responseBody)
            if decoded.candidates and decoded.candidates[1] and decoded.candidates[1].content then
                local text = decoded.candidates[1].content.parts[1].text
                callback(true, text)
            elseif decoded.promptFeedback and decoded.promptFeedback.blockReason then
                callback(false, "Bloqueado por seguridad (" .. tostring(decoded.promptFeedback.blockReason) .. "). Revisa la configuración de filtros.")
            else
                callback(false, "Respuesta vacía.")
            end
        else
            callback(false, "Error API: " .. code)
        end
    end)
end

return M