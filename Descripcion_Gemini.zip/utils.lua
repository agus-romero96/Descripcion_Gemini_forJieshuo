require "import"
import "android.util.Base64"
import "java.io.ByteArrayOutputStream"
import "android.graphics.Bitmap"
import "android.os.Vibrator"
import "android.content.Context"
import "android.graphics.Rect" -- Necesario para verificar si el botón es visible

local M = {}
local service

function M.init(srv)
    service = srv
end

function M.vibrate(ms)
    local v = service.getSystemService(Context.VIBRATOR_SERVICE)
    if v then v.vibrate(ms or 100) end
end

function M.bitmapToBase64(bitmap)
    local outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
    local byteArray = outputStream.toByteArray()
    return Base64.encodeToString(byteArray, Base64.NO_WRAP)
end

-- Captura Inteligente
-- mode: "full" (pantalla completa) o "element" (elemento enfocado)
-- node: El objeto del nodo de accesibilidad (pasado desde main o ui)
function M.captureScreen(mode, callback, node)
    local options = {
        onScreenCaptureDone = function(bitmap)
            if bitmap then
                local b64 = M.bitmapToBase64(bitmap)
                callback(b64)
            else
                service.asyncSpeak("Error: No se pudo capturar la imagen")
            end
        end
    }

    if mode == "full" then
        service.getScreenShot(options)
    elseif mode == "element" then
        -- Verificación de seguridad: ¿Existe el nodo?
        if node then
            -- Verificación extra: ¿El nodo tiene tamaño visual?
            local rect = Rect()
            node.getBoundsInScreen(rect)
            
            -- Si el ancho o alto es 0, es un nodo invisible -> Usar pantalla completa
            if rect.width() <= 0 or rect.height() <= 0 then
                service.asyncSpeak("Elemento sin imagen visible, capturando pantalla...")
                service.getScreenShot(options)
            else
                -- Nodo válido: Intentamos capturar solo el recorte
                local status, err = pcall(function()
                    service.getScreenShot(node, options)
                end)
                
                if not status then
                    service.asyncSpeak("Fallo al recortar, capturando pantalla...")
                    service.getScreenShot(options)
                end
            end
        else
            -- Si no se pasó un nodo válido
            service.asyncSpeak("No hay foco detectado, capturando pantalla...")
            service.getScreenShot(options)
        end
    end
end

return M