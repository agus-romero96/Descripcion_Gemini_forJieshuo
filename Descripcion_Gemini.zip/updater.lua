require "import"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.util.zip.ZipInputStream"
import "com.androlua.Http"
import "com.androlua.LuaDialog" -- Cambiamos AlertDialog por LuaDialog

local M = {}
local json = require("cjson")
local service, context, basePath

local VERSION_URL = "https://raw.githubusercontent.com/agus-romero96/Descripcion_Gemini_forJieshuo/main/version.json"

function M.init(srv, ctx, path)
    service = srv
    context = ctx
    basePath = path
end

-- Función para descomprimir el ZIP (Java puro)
local function unzip(zipFile, targetDir)
    local buffer = byte[1024]
    local zis = ZipInputStream(FileInputStream(zipFile))
    local entry = zis.getNextEntry()
    while entry do
        local fileName = entry.getName()
        local newFile = File(targetDir, fileName)
        if entry.isDirectory() then
            newFile.mkdirs()
        else
            newFile.getParentFile().mkdirs()
            local fos = FileOutputStream(newFile)
            local len = zis.read(buffer)
            while len > 0 do
                fos.write(buffer, 0, len)
                len = zis.read(buffer)
            end
            fos.close()
        end
        entry = zis.getNextEntry()
    end
    zis.closeEntry()
    zis.close()
end

-- Descargar e instalar
local function startUpdate(zipUrl)
    service.asyncSpeak("Descargando actualización...")
    local downloadPath = basePath .. "/update_temp.zip"
    
    Http.download(zipUrl, downloadPath, function(result)
        if result and File(downloadPath).exists() then
            service.asyncSpeak("Instalando...")
            task(50, function()
                local success, err = pcall(function()
                    unzip(downloadPath, basePath)
                    File(downloadPath).delete()
                end)
                if success then
                    service.asyncSpeak("¡Actualizado! Por favor, reinicia el plugin.")
                else
                    service.asyncSpeak("Error al instalar: " .. tostring(err))
                end
            end)
        else
            service.asyncSpeak("Error al descargar el archivo.")
        end
    end)
end

-- Función pública: Comprobar versión
function M.check(currentVersion)
    Http.get(VERSION_URL, function(code, body)
        if code == 200 and body then
            local data = json.decode(body)
            local remoteVersion = tonumber(data.version)
            local localVersion = tonumber(currentVersion)
            
            if remoteVersion and remoteVersion > localVersion then
                service.asyncSpeak("Nueva actualización disponible")
                
                -- Solución: Usar LuaDialog en lugar de AlertDialog.Builder
                local builder = LuaDialog(context)
                builder.setTitle("Actualización " .. remoteVersion)
                builder.setMessage("Novedades:\n" .. (data.changelog or "Mejoras generales") .. "\n\n¿Quieres actualizar ahora?")
                
                -- En LuaDialog, el botón recibe directamente la función, no una tabla con onClick
                builder.setPositiveButton("Sí, actualizar", function()
                    startUpdate(data.url)
                end)
                
                builder.setNegativeButton("Ahora no", nil)
                builder.show()
            end
        end
    end)
end

return M