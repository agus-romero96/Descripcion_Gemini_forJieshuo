require "import"
import "android.provider.MediaStore"
import "android.media.MediaMetadataRetriever"
import "java.io.File"
import "java.util.ArrayList"
import "android.graphics.Bitmap"
import "java.io.ByteArrayOutputStream"
import "android.util.Base64"

local M = {}
local context

function M.init(ctx)
    context = ctx
end

-- 1. LISTAR VIDEOS DE LA GALERÍA
function M.listarVideosRecientes(callback)
    local videos = {}
    
    -- Pedimos ID, Nombre y Fecha
    local projection = { 
        MediaStore.Video.Media.DATA, 
        MediaStore.Video.Media.DISPLAY_NAME, 
        MediaStore.Video.Media.DATE_MODIFIED 
    }
    
    -- Ordenamos del más nuevo al más viejo
    local sortOrder = MediaStore.Video.Media.DATE_MODIFIED .. " DESC"
    
    local cursor = context.getContentResolver().query(
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 
        projection, 
        nil, 
        nil, 
        sortOrder
    )

    if cursor then
        local colData = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
        local colName = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        
        -- Limitamos a los últimos 20 para que la lista cargue rápido
        local limit = 20
        while cursor.moveToNext() and limit > 0 do
            local path = cursor.getString(colData)
            local name = cursor.getString(colName)
            table.insert(videos, {name=name, path=path})
            limit = limit - 1
        end
        cursor.close()
    end
    
    callback(videos)
end

-- Función auxiliar para convertir imagen a texto para Gemini
function M.bitmapToBase64(bitmap)
    local outputStream = ByteArrayOutputStream()
    -- Calidad 50: Suficiente para que la IA vea, ligero para enviar 10 fotos rápido
    bitmap.compress(Bitmap.CompressFormat.JPEG, 50, outputStream) 
    local byteArray = outputStream.toByteArray()
    return Base64.encodeToString(byteArray, Base64.NO_WRAP)
end

-- 2. LA MAGIA: Extraer secuencia de fotos del video
function M.capturarSecuenciaVideo(videoPath)
    local retriever = MediaMetadataRetriever()
    local frames = {}
    
    local success, err = pcall(function()
        retriever.setDataSource(videoPath)
        
        -- Obtener duración del video
        local durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        local durationMs = tonumber(durationStr) or 0
        
        -- Si es muy corto (menos de 1 seg), sacamos 1 foto
        if durationMs < 1000 then
            local bmp = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if bmp then table.insert(frames, M.bitmapToBase64(bmp)) end
        else
            -- Si es largo, sacamos 10 fotos distribuidas (0%, 10%, 20%... 90%)
            local intervals = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9}
            
            for _, pct in ipairs(intervals) do
                local timePoint = (durationMs * 1000) * pct -- microsegundos
                -- OPTION_CLOSEST_SYNC es rápido
                local bmp = retriever.getFrameAtTime(timePoint, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if bmp then
                    table.insert(frames, M.bitmapToBase64(bmp))
                end
            end
        end
    end)
    
    -- Liberar memoria del extractor
    pcall(function() retriever.release() end)
    
    if #frames > 0 then
        return frames
    else
        return nil
    end
end

return M